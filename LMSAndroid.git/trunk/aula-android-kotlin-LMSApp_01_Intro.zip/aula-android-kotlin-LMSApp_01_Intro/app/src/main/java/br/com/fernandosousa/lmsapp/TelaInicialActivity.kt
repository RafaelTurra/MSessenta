package br.com.fernandosousa.lmsapp

import android.app.Activity
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_tela_inicial.*

class TelaInicialActivity : DebugActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_inicial)

        //TRAZER OS VALORES PARAMETROS CRIADOS NO MAINACTIVITY
        var nome = intent.getStringExtra("nomeUsuario")
        var numero = intent.getIntExtra("numero", 0)

        mensagemTelaInicial.setText(nome)

        botao_sair.setOnClickListener {
            val returnIntent = Intent()
            returnIntent.putExtra("result", "Saiu do LMS")
            setResult(Activity.RESULT_OK, returnIntent)
            finish()
        }

    }
}
